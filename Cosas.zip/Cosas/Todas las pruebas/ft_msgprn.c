#include "minishell.h"

void ft_msgprint(char *msg, int output)
{
	ft_putstr_fd(msg, output);
}

int ft_msgprint_err(char *msg, int err)
{
	ft_putstr_fd(msg, 2);
	return (err);
}
