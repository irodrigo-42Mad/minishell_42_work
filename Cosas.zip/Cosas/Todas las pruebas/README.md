# minishell_42_work

Working repository for minishell school proyect. All information in the files below

All files can be modified for proyect evaluation process.

Faltaa por modificar el makefile de la libft y el makefile principal, ojo con los wildcards (solo para pruebas)

gracias a por su ayuda
https://github.com/madebypixel02/minishell#lexer-and-expander
