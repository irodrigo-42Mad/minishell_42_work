Documentation of minishell_test
===============================

.. toctree::
   :maxdepth: 2

   config
   options
   bonus
   custom_test
   linux
   disclaimer
   developers

.. include:: disclaimer.rst

.. include:: gettingstarted.rst.inc
