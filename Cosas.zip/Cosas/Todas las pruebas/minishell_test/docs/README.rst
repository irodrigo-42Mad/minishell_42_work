minishell_test
==============

.. |pypi-python-version| image:: https://img.shields.io/pypi/pyversions/minishell-test
                         :alt: PyPI - Python Version
                         :target: https://pypi.org/project/minishell-test/
.. |documentation-build| image:: https://readthedocs.org/projects/minishell-test/badge/?version=latest
                         :alt: Documentation
                         :target: https://minishell-test.readthedocs.io
.. |travis-build| image:: https://api.travis-ci.com/cacharle/minishell_test.svg?branch=master
                  :alt: Build Status
                  :target: https://travis-ci.com/cacharle/minishell_test

|pypi-python-version| |documentation-build| |travis-build|

.. image:: https://i.imgur.com/98xh2xY.gif
   :alt: preview

Documentation
-------------

The full documentation for this project is available at `minishell-test.readthedocs.io <https://minishell-test.readthedocs.io>`_.

.. include:: gettingstarted.rst.inc
