.. program:: minishell_test

Disclaimer
==========

Environement variables
----------------------

| This test only gives the ``PATH`` and ``TERM`` environment variables to your minishell by default.
| You can change the value of ``PATH`` in the :ref:`configuration <config-path-variable>`.

You can test this quickly with :option:`--try`.

.. warning::
    Please check that your project still work with this environment before creating an issue or messaging me on Slack.

