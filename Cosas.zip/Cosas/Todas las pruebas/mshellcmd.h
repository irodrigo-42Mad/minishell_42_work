/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mshellcmd.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <irodrigo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/20 10:24:09 by irodrigo          #+#    #+#             */
/*   Updated: 2021/05/20 10:25:35 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MSHELLCMD_H
# define MSHELLCMD_H

/*
** para poner los comandos de el minishell si
** lo vemos necesario
*/

#endif
